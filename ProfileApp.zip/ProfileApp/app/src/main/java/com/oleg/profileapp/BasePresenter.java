package com.oleg.profileapp;

public interface BasePresenter {

    void start();

}
