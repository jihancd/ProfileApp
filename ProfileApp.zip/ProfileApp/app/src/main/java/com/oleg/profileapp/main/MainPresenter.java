package com.oleg.profileapp.main;

public class MainPresenter {
}
