package com.oleg.profileapp.profile;

public class ProfileContract {
}
